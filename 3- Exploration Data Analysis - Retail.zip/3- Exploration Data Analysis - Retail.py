
# coding: utf-8

# # EXPLORATION DATA ANALYSIS
# 
# ### BY Agboola Quam
# 
# **Performing ‘Exploratory Data Analysis’ on dataset ‘SampleSuperstore’, trying to find out the weak areas where I can work to
# make more profit.** 

# In[2]:


# import all packages and set plots to be embedded inline
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sb

get_ipython().run_line_magic('matplotlib', 'inline')


# In[3]:


# load in the dataset into a pandas dataframe, print statistics
store = pd.read_csv('SampleSuperstore.csv')
store.sample(10)


# In[4]:


#1 Checking the dimension of the store dataframe
store.shape


# **We have 9994 rows and 13 columns in our data frame**

# In[5]:


#2 Checking the data structure and also if there is missing value in any row in the data frame
store.info()


# In[6]:


#missing data
total = store.isnull().sum().sort_values(ascending=False)
percent = (store.isnull().sum()/store.isnull().count()).sort_values(ascending=False)
missing_data = pd.concat([total, percent], axis=1, keys=['Total', 'Percent'])
missing_data


# **It can be seen that no missing value exist in our dataframe**

# In[7]:


#Changing all the column names to lowercase and underscore for consistency and easy data cleaning.
store.rename(columns={'Profit':'profit','Discount':'discount','Quantity':'quantity','Sales':'sales','Sub-Category':'sub_category','Category':'category','Region':'region','Postal Code':'postal_code','State':'state','City':'city','Country':'country','Segment':'segment','Ship Mode':'ship_mode'},inplace=True)


# In[8]:


store.head(2)


# In[9]:


store.ship_mode=store.ship_mode.astype('category')


# In[10]:


store.segment=store.segment.astype('category')


# In[11]:


store.country=store.country.astype('category')


# In[12]:


store.city=store.city.astype('category')


# In[13]:


store.state=store.state.astype('category')


# In[14]:


store.region=store.region.astype('category')


# In[15]:


store.category=store.category.astype('category')


# In[16]:


store.sub_category=store.sub_category.astype('category')


# In[17]:


store.dtypes


# In[18]:


store.columns.tolist()


# In[19]:


#Checking unique values in each of our variable in the dataset
store.nunique()


# In[20]:


print(store.ship_mode.unique())
print(store.segment.unique())
print(store.region.unique())
print(store.category.unique())
print(store.sub_category.unique())


# ## DESCRIPTIVE STATISTICS

# In[21]:


store.describe()


# ### (1) SALES
# **Observations**
# 
# - We have 9994 customers in our dataset
# - The minimum amount of sales made in the dataset by a customer is 0.444
# - The maximum amount of sales made in the dataset by a customer is 22638.48
# - The average sales in the dataset is 229.858001
# - While the deviation is of 623.245101 sales
# 
# ### (2) QUANTITY
# **Observations**
# 
# - We have 9994 customers in our dataset
# - The minimum quantity of product bought by a customer in the dataset is 1
# - The maximum quantity of product bought by a customer in the dataset is 14
# - The average quantity bought in the dataset is 3.789574
# - While the deviation is of 2.225110 
# 
# ### (3) DISCOUNT
# **Observations**
# 
# - We have 9994 customers in our dataset
# - The minimum discount in the dataset is 0
# - The maximum discount in the dataset is 0.8
# - The average discount in the dataset is 0.156203
# - While the deviation is of 0.206452
# 
# ### (4) PROFIT
# **Observations**
# 
# - We have 9994 customers in our dataset
# - The minimum profit made from the business in the dataset is a loss of 6599.978000
# - The maximum profit made from the business in the dataset is a gain of 8399.976000
# - The average profit made from the business in the dataset is 28.656896
# - While the deviation is of 234.260108
# 

# ## EXPLORATION DATA ANALYSIS

# ### (1) Univariate exploration
# By looking at one variable at a time, we can build an intuition for how each variable is distributed before moving on to more complicated interactions between variables.
# 
# *Let's start our exploration by looking at the main variable of interest: price. Is the distribution skewed or symmetric? Is it unimodal or multimodal?*

# In[22]:


#Histogram plot for numeric variables in the titanic dataset
fig = plt.figure(figsize = (8,8))
ax = fig.gca()
store.hist(ax=ax)
plt.show()


# ## BAR CHART AND PIE CHART OF QUALITATIVE VARIABLE IN THE DATASET

# In[23]:


#Checking number of ship mode in the superstore dataset
pd.DataFrame(store.ship_mode.value_counts())


# In[24]:


#Checking number of segment in the superstore dataset
pd.DataFrame(store.segment.value_counts())


# In[25]:


#Checking number of cities in the superstore dataset
pd.DataFrame(store.city.value_counts())


# In[26]:


#Checking number of segment in the superstore dataset
pd.DataFrame(store.state.value_counts())


# In[27]:


#Checking number of region in the superstore dataset
pd.DataFrame(store.region.value_counts())


# In[28]:


#Checking number of segment in the superstore dataset
pd.DataFrame(store.category.value_counts())


# In[29]:


#Checking number of segment in the superstore dataset
pd.DataFrame(store.sub_category.value_counts())


# In[30]:


#Checking counts in our dataset with bar chart
plt.figure(figsize=(10,4))
plt.subplot(1,2,1);
store.ship_mode.value_counts().plot(kind='bar',title='CUSTOMERS SHIP MODE',color=['C0','C1','C2','C3']);
plt.xlabel('Ship modes')
plt.ylabel('Counts');

plt.subplot(1,2,2);
txn_values=[5968,1945,1538,543]
txn_labels=["Standard class","Second class","First class","Same day"]
plt.axis("equal")
plt.title("Pie chart showing the customers ship mode")
plt.pie(txn_values,labels=txn_labels,radius=1.0,autopct='%0.1f%%',shadow=True,explode=[0,0,0.1,0.1],wedgeprops={'edgecolor':'black'});


# In[31]:


#Checking counts in our dataset with bar chart
plt.figure(figsize=(10,4))
plt.subplot(1,2,1);
store.segment.value_counts().plot(kind='bar',title='CUSTOMERS SEGMENTS',color=['C4','C5','C6']);
plt.xlabel('Segment')
plt.ylabel('Counts');

plt.subplot(1,2,2);
seg_values=[5191,3020,1783]
seg_labels=["consumer","corporate","home office"]
plt.axis("equal")
plt.title("Pie chart showing the customers segments")
plt.pie(seg_values,labels=seg_labels,radius=1.0,autopct='%0.1f%%',shadow=True,explode=[0,0,0.1],wedgeprops={'edgecolor':'black'});


# In[32]:


#Checking counts in our dataset with bar chart
plt.figure(figsize=(10,4))
plt.subplot(1,2,1);
store.region.value_counts().plot(kind='bar',title='CUSTOMERS REGION',color=['C1','C2','C3','C4']);
plt.xlabel('Region')
plt.ylabel('Counts');

plt.subplot(1,2,2);
reg_values=[3203,2848,2323,1620]
reg_labels=["west","east","central","south"]
plt.axis("equal")
plt.title("Pie chart showing the customers segments")
plt.pie(reg_values,labels=reg_labels,radius=1.0,autopct='%0.1f%%',shadow=True,explode=[0,0,0.1,0.1],wedgeprops={'edgecolor':'black'});


# In[33]:


#Checking counts in our dataset with bar chart
plt.figure(figsize=(10,4))
plt.subplot(1,2,1);
store.category.value_counts().plot(kind='bar',title='CUSTOMERS CATEGORIES',color=['C4','C5','C6']);
plt.xlabel('Category')
plt.ylabel('Counts');

plt.subplot(1,2,2);
cat_values=[6026,2121,1847]
cat_labels=["office supplies","furniture","technology"]
plt.axis("equal")
plt.title("Pie chart showing the customers segments")
plt.pie(cat_values,labels=cat_labels,radius=1.0,autopct='%0.1f%%',shadow=True,explode=[0,0,0.1],wedgeprops={'edgecolor':'black'});


# In[34]:


#Checking counts in our dataset with bar chart
plt.figure(figsize=(22,12))
plt.subplot(1,2,1);
store.sub_category.value_counts().plot(kind='bar',title='CUSTOMERS SUB CATEGORIES',color=['red']);
plt.xlabel('Segment')
plt.ylabel('Counts');

plt.subplot(1,2,2);
sub_values=[1523,1370,957,889,846,796,775,617,466,364,319,254,228,217,190,115,68]
sub_labels=["binders","paper","furnish","phone","storage","art","accessories","chair","appliances","label","tabel","envelope","book case","fast","suplies","machines","copies"]
plt.axis("equal")
plt.title("Pie chart showing the customers segments")
plt.pie(sub_values,labels=sub_labels,radius=1.0,autopct='%0.1f%%',shadow=True,explode=[0,0,0.1,0,0,0.1,0,0,0.1,0.1,0,0,0,0,0,0.1,0],wedgeprops={'edgecolor':'black'});


# ## (2) Bivariate Exploration
# **To start off with, I want to look at the pairwise correlations present between features in the data**
# 
# *Through these bivariates plots, we can learn how changes in one variable might affect the variable in the second, and identify clusters and patterns in the dataset*

# In[35]:


numeric_vars = ['sales', 'quantity', 'discount','profit']
categoric_vars = ['ship_mode', 'segment', 'city','state','region','category','sub_category']


# In[36]:


plt.figure(figsize = [8, 5])
sb.heatmap(store[numeric_vars].corr(), annot = True, fmt = '.3f',
           cmap = 'vlag_r', center = 0)
plt.show()


# In[37]:


# plot matrix: checking relationship between the numerical variables in the dataset

g = sb.PairGrid(data = store, vars = numeric_vars)
g = g.map_diag(plt.hist, bins = 20);
g.map_offdiag(plt.scatter);


# In[38]:


cat_vars = ['ship_mode', 'segment','region','category']


# ### Plot matrix of numeric features against categorical features.

# In[39]:


# can use a larger sample since there are fewer plots and they're simpler in nature.


def boxgrid(x, y, **kwargs):
    """ Quick hack for creating box plots with seaborn's PairGrid. """
    default_color = sb.color_palette()[0]
    sb.boxplot(x, y, color = default_color)

plt.figure(figsize = [220, 220])
g = sb.PairGrid(data = store, y_vars = ['sales', 'quantity', 'discount', 'profit'], x_vars = cat_vars,
                size = 3, aspect = 1.5)
g.map(boxgrid)
plt.xticks(rotation='vertical',size=8)
plt.show();


# ### GROUPING TWO CATEGORICAL VARIABLES TOGETHER

# #### (1)SHIP MODE VS SEGMENTS

# In[40]:


#grouping two categorical variables together(ship mode vs segment)
byc=store.groupby("ship_mode").segment.value_counts()
byc


# In[41]:


#plotting clustered bar chart of ship mode vs segment
byc=byc.reset_index(name='count')
byc.pivot(index='ship_mode',columns='segment',values='count')


# In[42]:


sb.countplot(data=store,x='ship_mode',hue='segment')
plt.xticks(rotation=15)
plt.legend(loc="lower left", bbox_to_anchor=(0.5, 1.15), ncol=2)

plt.title('Segments by ship mode');


# #### (2)SHIP MODE VS REGION

# In[43]:


#grouping two categorical variables together(ship mode vs region)
byd=store.groupby("ship_mode").region.value_counts()
byd


# In[44]:


#plotting clustered bar chart of ship mode vs region
byd=byd.reset_index(name='count')
byd.pivot(index='ship_mode',columns='region',values='count')


# In[45]:


sb.countplot(data=store,x='ship_mode',hue='region')
plt.xticks(rotation=15)
plt.legend(loc="lower left", bbox_to_anchor=(0.5, 1.15), ncol=2)

plt.title('Ship mode by Region');


# #### (3)SHIP MODE VS CATEGORT

# In[46]:


#grouping two categorical variables together(ship mode vs category)
bye=store.groupby("ship_mode").category.value_counts()
bye


# In[47]:


#plotting clustered bar chart of ship mode vs category
bye=bye.reset_index(name='count')
bye.pivot(index='ship_mode',columns='category',values='count')


# In[48]:


sb.countplot(data=store,x='ship_mode',hue='category')
plt.xticks(rotation=15)
plt.legend(loc="lower left", bbox_to_anchor=(0.5, 1.15), ncol=2)

plt.title('Ship mode by Categories');


# #### (4)SHIP MODE VS SUB CATEGORIES

# In[49]:


#grouping two categorical variables together(ship mode vs sub category)
byf=store.groupby("ship_mode").sub_category.value_counts()
byf


# In[50]:


#plotting clustered bar chart of ship mode vs sub category
byf=byf.reset_index(name='count')
byf.pivot(index='ship_mode',columns='sub_category',values='count')


# In[51]:


sb.countplot(data=store,x='ship_mode',hue='sub_category')
plt.xticks(rotation=15)
plt.legend(loc="lower left", bbox_to_anchor=(0.5, 1.15), ncol=2)

plt.title('Ship mode by Sub Categories');


# #### (5)SEGMENTS VS REGION

# In[52]:


#grouping two categorical variables together(segment vs region)
byg=store.groupby("segment").region.value_counts()
byg


# In[53]:


#plotting clustered bar chart of segment vs region
byg=byg.reset_index(name='count')
byg.pivot(index='segment',columns='region',values='count')


# In[54]:


sb.countplot(data=store,x='segment',hue='region')
plt.xticks(rotation=15)
plt.legend(loc="lower left", bbox_to_anchor=(0.5, 1.15), ncol=2)

plt.title('Segments by Region');


# #### (6)SEGMENT VS CATEGORY

# In[55]:


#grouping two categorical variables together(segment vs categry)
byh=store.groupby("segment").category.value_counts()
byh


# In[56]:


#plotting clustered bar chart of segment vs category
byh=byh.reset_index(name='count')
byh.pivot(index='segment',columns='category',values='count')


# In[57]:


sb.countplot(data=store,x='segment',hue='category')
plt.xticks(rotation=15)
plt.legend(loc="lower left", bbox_to_anchor=(0.5, 1.15), ncol=2)

plt.title('Segments by Categories');


# #### (7)SEGMENT VS SUB CATEGORY

# In[58]:


#grouping two categorical variables together(segment vs sub categry)
byi=store.groupby("segment").sub_category.value_counts()
byi


# In[59]:


#plotting clustered bar chart of segment vs sub category
byi=byi.reset_index(name='count')
byi.pivot(index='segment',columns='sub_category',values='count')


# In[60]:


sb.countplot(data=store,x='segment',hue='sub_category')
plt.xticks(rotation=15)
plt.legend(loc="lower left", bbox_to_anchor=(0.5, 1.15), ncol=2)

plt.title('Segments by Sub Categories');


# #### (8)REGION VS CATEGORY

# In[61]:


#grouping two categorical variables together(region vs categry)
byj=store.groupby("region").category.value_counts()
byj


# In[62]:


#plotting clustered bar chart of region vs category
byj=byj.reset_index(name='count')
byj.pivot(index='region',columns='category',values='count')


# In[63]:


sb.countplot(data=store,x='region',hue='category')
plt.xticks(rotation=15)
plt.legend(loc="lower left", bbox_to_anchor=(0.5, 1.15), ncol=2)

plt.title('Region by Categories');


# #### (9)REGION VS SUB CATEGORY

# In[64]:


#grouping two categorical variables together(region vs sub categry)
byk=store.groupby("region").sub_category.value_counts()
byk


# In[65]:


#plotting clustered bar chart of region vs sub category
byk=byk.reset_index(name='count')
byk.pivot(index='region',columns='sub_category',values='count')


# In[66]:


sb.countplot(data=store,x='region',hue='sub_category')
plt.xticks(rotation=15)
plt.legend(loc="lower left", bbox_to_anchor=(0.5, 1.15), ncol=2)

plt.title('Region by Sub Categories');


# In[67]:


sb.pairplot(store)


# # QUESTIONS

# ### What are the top segment by sales

# In[68]:


#Grouping segment column
seg_sales=pd.DataFrame(store.groupby('segment').sum()['sales'])


# In[69]:


#Sorting segment column
seg_sales=seg_sales.sort_values('sales',ascending=False)
seg_sales


# ### What are the top ten city by sales

# In[70]:


#Grouping city column
city_sales=pd.DataFrame(store.groupby('city').sum()['sales'])


# In[71]:


#Sorting city column
city_sales=city_sales.sort_values('sales',ascending=False)
city_sales


# In[72]:


#Top ten city by sales
top_city=city_sales[:10]
top_city


# ### What are the top ten sales by state

# In[73]:


#Grouping state column
state_sales=pd.DataFrame(store.groupby('state').sum()['sales'])


# In[74]:


#Sorting state column
state_sales=state_sales.sort_values('sales',ascending=False)
state_sales


# In[75]:


#Top ten state by sales
state_sales[:10]


# ### Which region have the highest number of sales?

# In[76]:


#Grouping region column
region_sales=pd.DataFrame(store.groupby('region').sum()['sales'])


# In[77]:


#Sorting region column
#Top region by sales
region_sales=region_sales.sort_values('sales',ascending=False)
region_sales


# In[78]:


result=store.groupby('region').sum()
result


# In[79]:


reg=[region for region, store in store.groupby('region')]

plt.bar(reg,result['sales'])
plt.xticks(reg, rotation='vertical',size=8);
plt.ylabel('sales ($)')
plt.xlabel('region')
plt.title('Region By Sales');


# ### Top category by sales

# In[80]:


#Grouping category column
category_sales=pd.DataFrame(store.groupby('category').sum()['sales'])


# In[81]:


#Sorting region column
#Top category by sales
category_sales=category_sales.sort_values('sales',ascending=False)
category_sales


# In[82]:


res=store.groupby('category').sum()
res


# In[83]:


cat=[category for category, store in store.groupby('category')]

plt.bar(cat,res['sales'])
plt.xticks(cat, rotation='vertical',size=8);
plt.ylabel('sales ($)')
plt.xlabel('category')
plt.title('Category By Sales');


# ### Top sub category by sales

# In[84]:


#Grouping category column
subcategory_sales=pd.DataFrame(store.groupby('sub_category').sum()['sales'])


# In[85]:


#Sorting region column
#Top subcategory by sales
subcategory_sales=subcategory_sales.sort_values('sales',ascending=False)
subcategory_sales


# In[86]:


results=store.groupby('sub_category').sum()
results


# In[87]:


sub=[sub_category for sub_category, store in store.groupby('sub_category')]

plt.bar(sub,results['sales'])
plt.xticks(sub, rotation='vertical',size=8);
plt.ylabel('sales ($)')
plt.xlabel('sub_category')
plt.title('Sub Category By Sales');


# ### Which are the most selling segment by quantity

# In[88]:


#Grouping segment column
se_sales=pd.DataFrame(store.groupby('segment').sum()['quantity'])


# In[89]:


#Sorting segment column
se_sales=se_sales.sort_values('quantity',ascending=False)
se_sales


# ### Which are the most selling city by quantity 

# In[90]:


#Grouping city column
cit_sales=pd.DataFrame(store.groupby('city').sum()['quantity'])


# In[91]:


#Sorting city column
cit_sales=cit_sales.sort_values('quantity',ascending=False)
cit_sales


# In[92]:


#Top ten city by sales
cit_sales[:10]


# ### What is the most preferred ship mode

# In[93]:


#Checking number of ship mode in the superstore dataset
pd.DataFrame(store.ship_mode.value_counts())


# In[94]:


#Checking counts in our dataset with bar chart
plt.figure(figsize=(10,4))
plt.subplot(1,2,1);
store.ship_mode.value_counts().plot(kind='bar',title='CUSTOMERS SHIP MODE',color=['C0','C1','C2','C3']);
plt.xlabel('Ship modes')
plt.ylabel('Counts');

plt.subplot(1,2,2);
txn_values=[5968,1945,1538,543]
txn_labels=["Standard class","Second class","First class","Same day"]
plt.axis("equal")
plt.title("Pie chart showing the customers ship mode")
plt.pie(txn_values,labels=txn_labels,radius=1.0,autopct='%0.1f%%',shadow=True,explode=[0,0,0.1,0.1],wedgeprops={'edgecolor':'black'});


# ### Which are the most profitable category and sub category

# In[95]:


cat_pro=pd.DataFrame(store.groupby(['category','sub_category']).sum()['profit'])
cat_pro


# In[96]:


#Replace Nan with zero(0)
cat_pro=cat_pro.replace(np.nan, 0)
cat_pro


# In[97]:


#Most profitable category and sub category
cat_pro.sort_values(['category','profit'],ascending=False)

